import{a as e}from"./rolldown-runtime-BoInMwl7.js";import{i as t,r as n}from"./framer-motion-BipyvSml.js";import{s as r}from"./react-router-BM25cAUQ.js";import"./firebase-core-BsbS3RhF.js";import"./firebaseConfig-NMqbI0oP.js";import"./AuthContext-DlZ4D_Ma.js";import"./logo-CotKYXPH.js";import{t as i}from"./Navbar-mR8tqG5Y.js";import{t as a}from"./eventService-BhX4o2Y5.js";import{t as o}from"./EventCard-CfRWraOd.js";import{t as s}from"./Footer-FAPBSy9t.js";var c=e(t(),1),l=n(),u=()=>(0,l.jsxs)(`div`,{className:`glassbox-container`,style:{opacity:.7},children:[(0,l.jsx)(`div`,{className:`glassbox-inner bg-dark placeholder-glow`,children:(0,l.jsx)(`div`,{className:`placeholder w-100 h-100`})}),(0,l.jsxs)(`div`,{className:`glassbox-content placeholder-glow mt-3`,children:[(0,l.jsx)(`div`,{className:`placeholder col-8 mb-2`}),(0,l.jsx)(`div`,{className:`placeholder col-4`})]})]}),d=()=>{let[e,t]=(0,c.useState)([]),[n,d]=(0,c.useState)(!0),[f,p]=(0,c.useState)(`All`),[m,h]=(0,c.useState)(``),g=r();(0,c.useEffect)(()=>{let e=a(e=>{t(e),d(!1)},e=>{console.error(`Firestore fetch error:`,e),d(!1)},{eventType:`partner`});return()=>e()},[]);let _=[`All`,...new Set(e.map(e=>e.category||`Events`).filter(Boolean))],v=e.filter(e=>{let t=f===`All`||(e.category||`Events`)===f,n=m.toLowerCase(),r=!n||(e.title||``).toLowerCase().includes(n)||(e.location||``).toLowerCase().includes(n)||(e.organizer||``).toLowerCase().includes(n);return t&&r});return(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(i,{}),(0,l.jsx)(`section`,{id:`partner-events`,className:`pt-5 pb-5`,style:{marginTop:`60px`},children:(0,l.jsxs)(`div`,{className:`container`,children:[(0,l.jsxs)(`div`,{className:`d-flex flex-column flex-md-row justify-content-between align-items-md-end mb-4 fade-up gap-3`,children:[(0,l.jsxs)(`div`,{className:`text-start`,children:[(0,l.jsxs)(`h2`,{className:`section-title fw-black mb-1`,children:[`Partner `,(0,l.jsx)(`span`,{className:`text-gradient`,children:`Events`})]}),(0,l.jsxs)(`p`,{className:`text-white-50 mb-0 mt-2 small`,style:{maxWidth:`600px`},children:[(0,l.jsx)(`i`,{className:`bi bi-info-circle me-1`}),`Levitate Entertainment acts solely as a ticketing partner for these events. We provide secure ticketing services for external organizers.`]})]}),(0,l.jsxs)(`div`,{className:`pe-search-wrap`,children:[(0,l.jsx)(`i`,{className:`bi bi-search pe-search-icon`}),(0,l.jsx)(`input`,{className:`pe-search-input`,type:`text`,placeholder:`Search events, venues…`,value:m,onChange:e=>h(e.target.value)}),m&&(0,l.jsx)(`button`,{className:`pe-search-clear`,onClick:()=>h(``),children:(0,l.jsx)(`i`,{className:`bi bi-x`})})]})]}),_.length>1&&(0,l.jsx)(`div`,{className:`pe-category-strip custom-scrollbar fade-up mb-4`,children:_.map(e=>(0,l.jsx)(`button`,{className:`pe-cat-pill ${f===e?`pe-cat-pill-active`:``}`,onClick:()=>p(e),children:e},e))}),n?(0,l.jsx)(`div`,{className:`d-flex gap-3 overflow-x-auto pb-4 custom-scrollbar fade-up`,style:{scrollSnapType:`x mandatory`},children:[1,2,3].map(e=>(0,l.jsx)(`div`,{style:{scrollSnapAlign:`start`,flex:`0 0 auto`,width:`clamp(280px, 30vw, 350px)`},children:(0,l.jsx)(u,{})},e))}):v.length===0?(0,l.jsxs)(`div`,{className:`text-center py-5 fade-up`,children:[(0,l.jsx)(`div`,{className:`pe-empty-icon mb-4`,children:(0,l.jsx)(`i`,{className:`bi bi-calendar-x`})}),(0,l.jsx)(`h4`,{className:`fw-bold text-white mb-2`,children:m||f!==`All`?`No results found`:`No Partner Events Currently`}),(0,l.jsx)(`p`,{className:`text-white-50 small mb-4`,children:m||f!==`All`?`Try adjusting your search or category filter.`:`Check back soon — new events are added regularly.`}),(m||f!==`All`)&&(0,l.jsx)(`button`,{className:`btn btn-outline-custom px-4 py-2`,onClick:()=>{h(``),p(`All`)},children:`Clear Filters`})]}):(0,l.jsx)(`div`,{className:`d-flex gap-3 overflow-x-auto pb-4 custom-scrollbar fade-up`,style:{scrollSnapType:`x mandatory`,WebkitOverflowScrolling:`touch`,scrollBehavior:`smooth`},children:v.map(e=>(0,l.jsx)(`div`,{style:{scrollSnapAlign:`start`,flex:`0 0 auto`,width:`clamp(280px, 30vw, 350px)`},children:(0,l.jsx)(o,{eventData:e,onBook:e=>g(`/event/${e.slug||e.id}`)})},e.id))})]})}),(0,l.jsx)(s,{}),(0,l.jsx)(`style`,{children:`
        /* Search */
        .pe-search-wrap {
          position: relative;
          min-width: 220px;
          max-width: 300px;
          flex: 1;
        }
        .pe-search-icon {
          position: absolute;
          left: 14px;
          top: 50%;
          transform: translateY(-50%);
          color: rgba(255,255,255,0.4);
          font-size: 0.85rem;
          pointer-events: none;
        }
        .pe-search-input {
          width: 100%;
          background: rgba(255,255,255,0.06);
          border: 1px solid rgba(255,255,255,0.12);
          color: #fff;
          padding: 10px 36px 10px 38px;
          border-radius: 100px;
          font-size: 0.85rem;
          outline: none;
          transition: border-color 0.2s, box-shadow 0.2s;
          font-family: 'Plus Jakarta Sans', sans-serif;
        }
        .pe-search-input::placeholder { color: rgba(255,255,255,0.3); }
        .pe-search-input:focus {
          border-color: rgba(168,85,247,0.5);
          box-shadow: 0 0 0 3px rgba(168,85,247,0.12);
        }
        .pe-search-clear {
          position: absolute;
          right: 10px;
          top: 50%;
          transform: translateY(-50%);
          background: rgba(255,255,255,0.1);
          border: none;
          color: #fff;
          width: 22px;
          height: 22px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          font-size: 0.85rem;
          transition: background 0.2s;
        }
        .pe-search-clear:hover { background: rgba(255,255,255,0.2); }

        /* Category pills */
        .pe-category-strip {
          display: flex;
          gap: 10px;
          overflow-x: auto;
          padding-bottom: 4px;
          scrollbar-width: none;
        }
        .pe-category-strip::-webkit-scrollbar { display: none; }
        .pe-cat-pill {
          flex-shrink: 0;
          padding: 7px 18px;
          border-radius: 100px;
          border: 1px solid rgba(255,255,255,0.15);
          background: rgba(255,255,255,0.05);
          color: rgba(255,255,255,0.65);
          font-size: 0.8rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          white-space: nowrap;
          font-family: 'Plus Jakarta Sans', sans-serif;
        }
        .pe-cat-pill:hover {
          background: rgba(168,85,247,0.15);
          border-color: rgba(168,85,247,0.4);
          color: #fff;
        }
        .pe-cat-pill-active {
          background: linear-gradient(135deg, #a855f7, #ec4899) !important;
          border-color: transparent !important;
          color: #fff !important;
          box-shadow: 0 0 18px rgba(168,85,247,0.35);
        }

        /* Empty state icon */
        .pe-empty-icon {
          width: 72px;
          height: 72px;
          border-radius: 50%;
          background: rgba(168,85,247,0.1);
          border: 1px solid rgba(168,85,247,0.2);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.8rem;
          color: rgba(168,85,247,0.7);
          margin: 0 auto;
        }
      `})]})};export{d as default};