import{a as e}from"./rolldown-runtime-BoInMwl7.js";import{i as t,r as n}from"./framer-motion-BipyvSml.js";t();var r=n(),i=({text:e=`Loading...`,fullScreen:t=!1})=>(0,r.jsxs)(`div`,{className:t?`min-vh-100 w-100 d-flex flex-column align-items-center justify-content-center`:`d-flex flex-column align-items-center justify-content-center py-5`,style:{backgroundColor:t?`#05020a`:`transparent`,zIndex:9999},children:[(0,r.jsxs)(`div`,{className:`position-relative d-flex align-items-center justify-content-center`,style:{width:`80px`,height:`80px`},children:[(0,r.jsx)(`div`,{className:`position-absolute rounded-circleSpinner`,style:{width:`100%`,height:`100%`,border:`4px solid transparent`,borderTopColor:`#f97316`,borderRightColor:`#ec4899`,borderBottomColor:`#a855f7`,opacity:.8,animation:`spinSpinner 1.5s linear infinite`}}),(0,r.jsx)(`div`,{className:`position-absolute rounded-circleSpinner`,style:{width:`60%`,height:`60%`,border:`3px solid transparent`,borderTopColor:`#ec4899`,borderLeftColor:`#f97316`,opacity:.6,animation:`spinSpinnerInverse 2s linear infinite`}}),(0,r.jsx)(`div`,{className:`rounded-circleSpinner`,style:{width:`20px`,height:`20px`,background:`linear-gradient(135deg, #a855f7 0%, #ec4899 50%, #f97316 100%)`,boxShadow:`0 0 20px 5px rgba(236, 72, 153, 0.5)`,animation:`pulseSpinner 1.5s ease-in-out infinite`}})]}),e&&(0,r.jsx)(`div`,{className:`mt-4 fw-bold text-uppercase`,style:{letterSpacing:`2px`,background:`linear-gradient(135deg, #a855f7 0%, #ec4899 50%, #f97316 100%)`,WebkitBackgroundClip:`text`,WebkitTextFillColor:`transparent`,animation:`pulseSpinnerText 2s ease-in-out infinite`},children:e}),(0,r.jsx)(`style`,{children:`
        .rounded-circleSpinner {
          border-radius: 50%;
        }
        @keyframes spinSpinner {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes spinSpinnerInverse {
          from { transform: rotate(0deg); }
          to { transform: rotate(-360deg); }
        }
        @keyframes pulseSpinner {
          0%, 100% { transform: scale(0.8); opacity: 0.5; }
          50% { transform: scale(1.2); opacity: 1; }
        }
        @keyframes pulseSpinnerText {
          0%, 100% { opacity: 0.5; }
          50% { opacity: 1; }
        }
      `})]});export{i as t};